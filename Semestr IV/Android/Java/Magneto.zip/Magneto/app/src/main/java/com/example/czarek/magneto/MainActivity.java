package com.example.czarek.magneto;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;

import com.github.anastr.speedviewlib.SpeedView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Random;

import de.nitri.gauge.Gauge;


import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView value;
    private TextView warning;
    private ToneGenerator toneGenerator;
    private SensorManager sensorManager;
    public static DecimalFormat DECIMAL_FORMATTER;

    private Gauge gauge;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        value = (TextView) findViewById(R.id.value);
        warning = (TextView) findViewById(R.id.warning);
        toneGenerator = new ToneGenerator(AudioManager.STREAM_ALARM, 50);
        gauge = (Gauge) findViewById(R.id.gauge);


        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        symbols.setDecimalSeparator('.');
        DECIMAL_FORMATTER = new DecimalFormat("#.000", symbols);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);


    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected void onPause() {

        super.onPause();
        sensorManager.unregisterListener(this);
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        int expectedMagnitude = 50;


        if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];

            final double magnitude = Math.sqrt(x * x + y * y + z * z);

            float magnitudeF = (float) magnitude;

            value.setText(DECIMAL_FORMATTER.format(magnitude) + " \u00B5Tesla");
            gauge.moveToValue((int) magnitude);



            if (magnitude > 1.4 * expectedMagnitude || magnitude < 0.6 * expectedMagnitude) {
                //metal detected
                warning.setText("METAL DETECTED!");

                toneGenerator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200);

                // warningBlink();

            } else {
                //everything is normal
                warning.setText("");
                toneGenerator.stopTone();
            }
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


    private void warningBlink() {
        final Handler handler = new Handler();
        new Thread(new Runnable() {
            @Override
            public void run() {
                int timeToBlink = 500;
                try {
                    Thread.sleep(timeToBlink);
                } catch (Exception e) {
                }
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TextView text = (TextView) findViewById(R.id.warning);
                        if (text.getVisibility() == View.VISIBLE) {
                            text.setVisibility(View.INVISIBLE);
                        } else {
                            text.setVisibility(View.VISIBLE);
                        }
                        warningBlink();
                    }
                });
            }
        });
    }


}
